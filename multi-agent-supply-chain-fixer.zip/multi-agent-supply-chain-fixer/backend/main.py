"""
backend/main.py
------------------
Main FastAPI application entry point.

Run with:
    cd backend
    uvicorn main:app --reload

This file:
1. Adds the project root to sys.path so the sibling `agents/`, `api/`
   and `database/` packages (which live one level up, per the requested
   project structure) can be imported normally.
2. Initializes the SQLite database + seeds sample data on startup.
3. Registers every API router.
4. Configures CORS so the React frontend (localhost:3000) can call the API.
"""

import os
import sys

# ---------------------------------------------------------------------------
# Make the project root importable (so `agents`, `api`, `database` resolve)
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database.db import init_db
from database.seed import seed_if_empty

from api.routes_inventory import router as inventory_router
from api.routes_suppliers import router as suppliers_router
from api.routes_shipments import router as shipments_router
from api.routes_forecast import router as forecast_router
from api.routes_risk import router as risk_router
from api.routes_agent import router as agent_router
from api.routes_auth import router as auth_router


app = FastAPI(
    title="Multi-Agent Supply Chain Fixer API",
    description="AI-powered multi-agent supply chain monitoring & decision system.",
    version="1.0.0",
)

# ---------------------------------------------------------------------------
# CORS - allow the React dev server to talk to this API
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],       # relaxed for local development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup_event():
    """Runs once when the server starts: create tables + seed sample data."""
    init_db()
    seed_if_empty()


@app.get("/")
def root():
    """Simple health check / welcome route."""
    return {
        "message": "Multi-Agent Supply Chain Fixer API is running.",
        "docs": "/docs",
    }


# ---------------------------------------------------------------------------
# Register all routers
# ---------------------------------------------------------------------------
app.include_router(inventory_router)
app.include_router(suppliers_router)
app.include_router(shipments_router)
app.include_router(forecast_router)
app.include_router(risk_router)
app.include_router(agent_router)
app.include_router(auth_router)
