"""
agents/supplier_agent.py
----------------------------
SUPPLIER AGENT

Responsibilities:
- Evaluate supplier performance (rating + delivery time)
- Compare supplier delivery times
- Suggest the best supplier for a reorder
- Handle supplier delays by proposing a backup supplier
"""

from database.db import get_connection
from agents.llm_helper import enrich_with_llm


class SupplierAgent:
    name = "Supplier Agent"

    def get_all_suppliers(self):
        conn = get_connection()
        rows = conn.execute("SELECT * FROM suppliers").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def rank_suppliers(self):
        """
        Ranks suppliers with a weighted score:
        70% supplier rating, 30% delivery speed (faster = better).
        Returns suppliers sorted best -> worst.
        """
        suppliers = self.get_all_suppliers()
        if not suppliers:
            return []

        max_delivery = max(s["delivery_time"] for s in suppliers) or 1
        for s in suppliers:
            speed_score = 1 - (s["delivery_time"] / max_delivery)  # faster => closer to 1
            s["score"] = round((s["rating"] / 5) * 0.7 + speed_score * 0.3, 3)

        return sorted(suppliers, key=lambda s: s["score"], reverse=True)

    def best_supplier(self):
        ranked = self.rank_suppliers()
        return ranked[0] if ranked else None

    def handle_delay(self, supplier_id):
        """
        Suggests the best alternative supplier when the given supplier_id
        is experiencing delays.
        """
        ranked = [s for s in self.rank_suppliers() if s["id"] != supplier_id]
        return ranked[0] if ranked else None

    def analyze_query(self, query: str):
        """Called by the Coordinator Agent to get a supplier recommendation."""
        best = self.best_supplier()
        if not best:
            summary = "No supplier data available."
        else:
            summary = (
                f"Best available supplier is {best['supplier_name']} "
                f"(rating {best['rating']}/5, average delivery time {best['delivery_time']} days). "
                f"Recommend placing the reorder with this supplier."
            )
        return {
            "agent": self.name,
            "recommended_supplier": best["supplier_name"] if best else None,
            "delivery_time": best["delivery_time"] if best else None,
            "message": enrich_with_llm(self.name, summary),
        }
