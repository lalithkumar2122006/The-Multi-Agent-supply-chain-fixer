"""
agents/risk_agent.py
----------------------------
RISK ANALYSIS AGENT

Responsibilities:
- Detect overall supply chain risks
- Predict stock shortages
- Predict supplier failures
- Generate an overall numeric risk score (0-100) and severity label
"""

from database.db import get_connection
from agents.llm_helper import enrich_with_llm


class RiskAgent:
    name = "Risk Analysis Agent"

    def get_all_risks(self):
        conn = get_connection()
        rows = conn.execute("SELECT * FROM risks").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def calculate_risk_score(self):
        """
        Builds a composite 0-100 risk score from three live signals:
        - % of products below minimum stock
        - % of shipments delayed
        - % of suppliers with rating < 4.0
        Higher score = higher risk.
        """
        conn = get_connection()
        inventory = conn.execute("SELECT * FROM inventory").fetchall()
        shipments = conn.execute("SELECT * FROM shipments").fetchall()
        suppliers = conn.execute("SELECT * FROM suppliers").fetchall()
        conn.close()

        low_stock_ratio = (
            sum(1 for i in inventory if i["stock"] <= i["minimum_stock"]) / len(inventory)
            if inventory else 0
        )
        delayed_ratio = (
            sum(1 for s in shipments if s["status"] == "Delayed") / len(shipments)
            if shipments else 0
        )
        weak_supplier_ratio = (
            sum(1 for s in suppliers if s["rating"] < 4.0) / len(suppliers)
            if suppliers else 0
        )

        score = round(
            (low_stock_ratio * 50) + (delayed_ratio * 30) + (weak_supplier_ratio * 20), 1
        )
        score = min(score, 100)

        if score >= 60:
            level = "High"
        elif score >= 30:
            level = "Medium"
        else:
            level = "Low"

        return {
            "score": score,
            "level": level,
            "low_stock_ratio": round(low_stock_ratio * 100, 1),
            "delayed_ratio": round(delayed_ratio * 100, 1),
            "weak_supplier_ratio": round(weak_supplier_ratio * 100, 1),
        }

    def add_risk(self, risk_type, severity, solution):
        conn = get_connection()
        conn.execute(
            "INSERT INTO risks (risk_type, severity, solution) VALUES (?, ?, ?)",
            (risk_type, severity, solution),
        )
        conn.commit()
        conn.close()

    def analyze_query(self, query: str):
        """Called by the Coordinator Agent to give an overall risk verdict."""
        risk = self.calculate_risk_score()
        summary = (
            f"Overall supply chain risk score is {risk['score']}/100 ({risk['level']} risk). "
            f"Key contributors: {risk['low_stock_ratio']}% of products below minimum stock, "
            f"{risk['delayed_ratio']}% of shipments delayed, "
            f"{risk['weak_supplier_ratio']}% of suppliers under-performing."
        )
        return {
            "agent": self.name,
            "risk_score": risk["score"],
            "risk_level": risk["level"],
            "message": enrich_with_llm(self.name, summary),
        }
