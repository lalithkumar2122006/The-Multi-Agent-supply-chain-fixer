"""
agents/llm_helper.py
----------------------
This project is built so it ALWAYS works out of the box, even without any
API keys configured. Every agent's core logic is rule-based (deterministic,
fast, free) so the demo never breaks.

HOWEVER, if the user provides an OPENAI_API_KEY or GROQ_API_KEY environment
variable, this helper will use LangChain to call a real LLM to turn the
agent's structured findings into a more natural, human-like explanation.

This gives the "AI Framework: CrewAI / LangChain / OpenAI / Groq" behaviour
requested, while keeping the system fully functional without any paid keys.
"""

import os

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")
GROQ_KEY = os.getenv("GROQ_API_KEY", "")

LLM_ENABLED = bool(OPENAI_KEY or GROQ_KEY)


def enrich_with_llm(agent_name: str, structured_summary: str) -> str:
    """
    If an API key is configured, ask a real LLM (through LangChain) to
    rewrite the structured summary in a more natural voice.
    Otherwise, simply return the structured summary unchanged.

    This function NEVER raises - if anything about the LLM call fails
    (no internet, bad key, package missing) it silently falls back to the
    rule-based text so the API endpoint never breaks.
    """
    if not LLM_ENABLED:
        return structured_summary

    try:
        from langchain_core.messages import HumanMessage, SystemMessage

        if OPENAI_KEY:
            from langchain_openai import ChatOpenAI
            llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.3, api_key=OPENAI_KEY)
        else:
            from langchain_groq import ChatGroq
            llm = ChatGroq(model="llama-3.1-70b-versatile", temperature=0.3, api_key=GROQ_KEY)

        messages = [
            SystemMessage(content=(
                f"You are the {agent_name} in a supply chain management system. "
                "Rewrite the following structured finding as a short, clear, "
                "professional 1-2 sentence recommendation for a supply chain manager."
            )),
            HumanMessage(content=structured_summary),
        ]
        response = llm.invoke(messages)
        return response.content.strip()
    except Exception:
        # Fallback safety net - never break the pipeline because of the LLM
        return structured_summary
