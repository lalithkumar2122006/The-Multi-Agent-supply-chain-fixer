"""
agents/coordinator_agent.py
------------------------------
COORDINATOR AGENT

Responsibilities:
- Receive the user's natural language query (e.g. "I have only 20 laptops left.")
- Assign / delegate the query to every specialist agent, in this order:
    Inventory -> Supplier -> Logistics -> Forecast -> Risk
- Collect each agent's structured response
- Combine everything into ONE final, human-readable recommendation

This mirrors a CrewAI "Crew" with a manager agent and worker agents, but is
implemented with plain, dependency-light Python so the whole project runs
instantly without requiring a CrewAI/OpenAI account. If the optional
`crewai` package + an API key ARE installed/configured, this same class
can be swapped to build a real `Crew` object (see `build_crewai_crew`
below) - both paths produce the same JSON contract for the frontend.
"""

import datetime
from database.db import get_connection
from agents.inventory_agent import InventoryAgent
from agents.supplier_agent import SupplierAgent
from agents.logistics_agent import LogisticsAgent
from agents.forecast_agent import ForecastAgent
from agents.risk_agent import RiskAgent
from agents.llm_helper import enrich_with_llm, LLM_ENABLED


class CoordinatorAgent:
    name = "Coordinator Agent"

    def __init__(self):
        self.inventory_agent = InventoryAgent()
        self.supplier_agent = SupplierAgent()
        self.logistics_agent = LogisticsAgent()
        self.forecast_agent = ForecastAgent()
        self.risk_agent = RiskAgent()

    def _log(self, agent_name, message):
        """Writes a row to agent_logs so the frontend's 'Agent Activity' page
        can show a real-time (polling-based) feed of what each agent did."""
        conn = get_connection()
        conn.execute(
            "INSERT INTO agent_logs (agent_name, message, timestamp) VALUES (?, ?, ?)",
            (agent_name, message, datetime.datetime.now().isoformat()),
        )
        conn.commit()
        conn.close()

    def handle_query(self, query: str):
        """
        Runs the full multi-agent pipeline for a single user query and
        returns a combined JSON result:

            Coordinator Agent
              -> Inventory Agent
              -> Supplier Agent
              -> Logistics Agent
              -> Forecast Agent
              -> Risk Agent
              -> Coordinator combines all outputs
              -> Return final recommendation
        """
        self._log(self.name, f"Received user query: '{query}'")

        # ---- Step 1: Inventory Agent ----
        inventory_result = self.inventory_agent.analyze_query(query)
        self._log(inventory_result["agent"], inventory_result["message"])

        # ---- Step 2: Supplier Agent ----
        supplier_result = self.supplier_agent.analyze_query(query)
        self._log(supplier_result["agent"], supplier_result["message"])

        # ---- Step 3: Logistics Agent ----
        logistics_result = self.logistics_agent.analyze_query(query)
        self._log(logistics_result["agent"], logistics_result["message"])

        # ---- Step 4: Forecast Agent ----
        forecast_result = self.forecast_agent.analyze_query(query)
        self._log(forecast_result["agent"], forecast_result["message"])

        # ---- Step 5: Risk Agent ----
        risk_result = self.risk_agent.analyze_query(query)
        self._log(risk_result["agent"], risk_result["message"])

        # ---- Step 6: Coordinator combines everything ----
        final_recommendation = self._build_final_recommendation(
            inventory_result, supplier_result, logistics_result, forecast_result, risk_result
        )
        self._log(self.name, final_recommendation)

        return {
            "query": query,
            "pipeline": [
                inventory_result,
                supplier_result,
                logistics_result,
                forecast_result,
                risk_result,
            ],
            "final_recommendation": final_recommendation,
            "llm_enabled": LLM_ENABLED,
        }

    def _build_final_recommendation(self, inv, sup, log, fcst, risk):
        """
        Combines the 5 agents' findings into one actionable recommendation,
        mirroring the example in the spec:
        'Recommended order quantity: 150 laptops immediately.'
        """
        pieces = []

        if inv.get("is_low_stock") and inv.get("matched_product"):
            qty = inv["reorder_quantity"]
            # Bump quantity up if forecast shows a demand spike, for a smarter recommendation
            if fcst.get("is_spike"):
                qty = int(qty * 1.3)
            pieces.append(
                f"Recommended order quantity: {qty} units of {inv['matched_product']} immediately."
            )
            if sup.get("recommended_supplier"):
                pieces.append(f"Place the order with {sup['recommended_supplier']}.")
            if log.get("express_recommended"):
                pieces.append("Use express delivery to avoid further shortage.")
            if fcst.get("is_spike"):
                pieces.append(
                    f"Demand for {fcst['product']} is projected to rise "
                    f"{abs(fcst['spike_percent'])}%, so the order has been scaled up accordingly."
                )
        else:
            pieces.append("No immediate reorder is required based on current data.")

        pieces.append(f"Overall supply chain risk level: {risk['risk_level']} ({risk['risk_score']}/100).")

        summary = " ".join(pieces)
        return enrich_with_llm(self.name, summary)


# ---------------------------------------------------------------------------
# OPTIONAL: real CrewAI wiring.
# This function is not called by default (to keep the app dependency-light
# and runnable without API keys), but shows how this exact same agent logic
# could be wrapped as a genuine CrewAI Crew if the user installs `crewai`
# and sets an OPENAI_API_KEY / GROQ_API_KEY.
# ---------------------------------------------------------------------------
def build_crewai_crew(query: str):
    """
    Example of building a real CrewAI Crew using the same responsibilities.
    Requires: pip install crewai crewai-tools
    Requires: OPENAI_API_KEY (or Groq via litellm) set in the environment.
    """
    from crewai import Agent, Task, Crew, Process

    inventory_agent = Agent(
        role="Inventory Agent",
        goal="Monitor stock levels and recommend reorder quantities",
        backstory="An expert in warehouse stock control and reorder timing.",
        verbose=False,
    )
    supplier_agent = Agent(
        role="Supplier Agent",
        goal="Evaluate and recommend the best supplier",
        backstory="An expert in vendor performance analysis.",
        verbose=False,
    )
    logistics_agent = Agent(
        role="Logistics Agent",
        goal="Track shipments and recommend faster routes",
        backstory="An expert in freight and delivery route optimization.",
        verbose=False,
    )
    forecast_agent = Agent(
        role="Demand Forecast Agent",
        goal="Predict future product demand",
        backstory="A data-driven demand planning specialist.",
        verbose=False,
    )
    risk_agent = Agent(
        role="Risk Analysis Agent",
        goal="Generate an overall supply chain risk score",
        backstory="A risk management expert for global supply chains.",
        verbose=False,
    )
    coordinator = Agent(
        role="Coordinator Agent",
        goal="Combine every agent's findings into one final recommendation",
        backstory="A supply chain operations director.",
        verbose=False,
    )

    tasks = [
        Task(description=f"Analyze inventory for: {query}", agent=inventory_agent, expected_output="Inventory status"),
        Task(description=f"Recommend a supplier for: {query}", agent=supplier_agent, expected_output="Best supplier"),
        Task(description=f"Check logistics for: {query}", agent=logistics_agent, expected_output="Shipment status"),
        Task(description=f"Forecast demand for: {query}", agent=forecast_agent, expected_output="Demand forecast"),
        Task(description=f"Assess risk for: {query}", agent=risk_agent, expected_output="Risk score"),
        Task(description="Combine all findings into one final recommendation", agent=coordinator, expected_output="Final recommendation"),
    ]

    crew = Crew(
        agents=[inventory_agent, supplier_agent, logistics_agent, forecast_agent, risk_agent, coordinator],
        tasks=tasks,
        process=Process.sequential,
    )
    return crew.kickoff()
