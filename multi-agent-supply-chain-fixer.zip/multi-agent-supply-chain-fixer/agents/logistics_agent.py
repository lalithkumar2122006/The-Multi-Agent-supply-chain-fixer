"""
agents/logistics_agent.py
----------------------------
LOGISTICS AGENT

Responsibilities:
- Track shipments
- Detect delayed deliveries
- Recommend faster routes / express delivery when needed
- Update shipment status
"""

from database.db import get_connection
from agents.llm_helper import enrich_with_llm


class LogisticsAgent:
    name = "Logistics Agent"

    def get_all_shipments(self):
        conn = get_connection()
        rows = conn.execute("SELECT * FROM shipments").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def detect_delayed(self):
        conn = get_connection()
        rows = conn.execute("SELECT * FROM shipments WHERE status = 'Delayed'").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def update_status(self, shipment_id, new_status):
        conn = get_connection()
        conn.execute("UPDATE shipments SET status = ? WHERE id = ?", (new_status, shipment_id))
        conn.commit()
        conn.close()

    def analyze_query(self, query: str):
        """Called by the Coordinator Agent to report on shipment health / express options."""
        delayed = self.detect_delayed()
        express_needed = "urgent" in query.lower() or "immediately" in query.lower() or len(delayed) > 0

        if delayed:
            summary = (
                f"{len(delayed)} shipment(s) currently delayed: "
                f"{', '.join(d['tracking_id'] for d in delayed)}. "
                f"Express delivery route is recommended to recover lost time."
            )
        else:
            summary = "No delayed shipments detected. Standard delivery routes are on schedule."

        return {
            "agent": self.name,
            "delayed_shipments": [d["tracking_id"] for d in delayed],
            "express_recommended": express_needed,
            "message": enrich_with_llm(self.name, summary),
        }
