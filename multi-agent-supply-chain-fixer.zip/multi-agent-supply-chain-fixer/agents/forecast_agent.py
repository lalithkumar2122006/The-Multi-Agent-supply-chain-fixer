"""
agents/forecast_agent.py
----------------------------
DEMAND FORECAST AGENT

Responsibilities:
- Predict future demand for products
- Analyze sales/stock history
- Detect demand spikes
"""

from database.db import get_connection
from agents.llm_helper import enrich_with_llm


class ForecastAgent:
    name = "Demand Forecast Agent"

    def get_all_forecasts(self):
        conn = get_connection()
        rows = conn.execute("SELECT * FROM forecast").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def detect_spike(self, product_name):
        """
        Compares predicted demand against current stock (from inventory)
        to compute a percentage spike. A spike >= 25% is considered significant.
        """
        conn = get_connection()
        forecast_row = conn.execute(
            "SELECT * FROM forecast WHERE product = ?", (product_name,)
        ).fetchone()
        inventory_row = conn.execute(
            "SELECT * FROM inventory WHERE product_name = ?", (product_name,)
        ).fetchone()
        conn.close()

        if not forecast_row or not inventory_row:
            return None

        predicted = forecast_row["predicted_demand"]
        current_stock = inventory_row["stock"]
        if current_stock == 0:
            spike_percent = 100
        else:
            spike_percent = round(((predicted - current_stock) / current_stock) * 100, 1)

        return {
            "product": product_name,
            "predicted_demand": predicted,
            "current_stock": current_stock,
            "spike_percent": spike_percent,
            "is_spike": spike_percent >= 25,
        }

    def analyze_query(self, query: str):
        """Called by the Coordinator Agent to give a demand outlook for a mentioned product."""
        conn = get_connection()
        inventory_rows = conn.execute("SELECT product_name FROM inventory").fetchall()
        conn.close()

        matched_product = None
        for row in inventory_rows:
            if row["product_name"].lower().split()[0] in query.lower():
                matched_product = row["product_name"]
                break

        if matched_product:
            spike_info = self.detect_spike(matched_product)
            if spike_info:
                summary = (
                    f"Demand for {matched_product} is expected to "
                    f"{'increase' if spike_info['spike_percent'] >= 0 else 'decrease'} by "
                    f"{abs(spike_info['spike_percent'])}% based on current trends "
                    f"(predicted demand: {spike_info['predicted_demand']} units)."
                )
                return {
                    "agent": self.name,
                    "product": matched_product,
                    "spike_percent": spike_info["spike_percent"],
                    "is_spike": spike_info["is_spike"],
                    "message": enrich_with_llm(self.name, summary),
                }

        summary = "No specific product forecast matched this query; overall demand trends remain stable."
        return {
            "agent": self.name,
            "product": None,
            "spike_percent": 0,
            "is_spike": False,
            "message": enrich_with_llm(self.name, summary),
        }
