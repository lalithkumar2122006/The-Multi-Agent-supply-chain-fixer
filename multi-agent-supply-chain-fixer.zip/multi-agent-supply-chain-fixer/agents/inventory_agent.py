"""
agents/inventory_agent.py
----------------------------
INVENTORY AGENT

Responsibilities:
- Monitor stock levels for every product
- Detect products that have fallen below their minimum stock threshold
- Recommend a reorder quantity for low-stock products
- Update the inventory database when stock changes
"""

from database.db import get_connection
from agents.llm_helper import enrich_with_llm


class InventoryAgent:
    name = "Inventory Agent"

    def get_all_inventory(self):
        """Returns every inventory row as a list of dicts."""
        conn = get_connection()
        rows = conn.execute("SELECT * FROM inventory").fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def detect_low_stock(self):
        """Returns only the products whose stock is at/below minimum_stock."""
        conn = get_connection()
        rows = conn.execute(
            "SELECT * FROM inventory WHERE stock <= minimum_stock"
        ).fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def recommend_reorder_quantity(self, product):
        """
        Simple, explainable reorder-quantity heuristic:
        reorder = (minimum_stock * 2) - current_stock, floored at minimum_stock.
        This brings stock back up to a healthy buffer above the minimum.
        """
        deficit = (product["minimum_stock"] * 2) - product["stock"]
        return max(deficit, product["minimum_stock"])

    def add_inventory_item(self, product_name, stock, minimum_stock, location):
        """Inserts a new inventory row (used by POST /inventory)."""
        conn = get_connection()
        conn.execute(
            "INSERT INTO inventory (product_name, stock, minimum_stock, location) VALUES (?, ?, ?, ?)",
            (product_name, stock, minimum_stock, location),
        )
        conn.commit()
        conn.close()

    def update_stock(self, product_id, new_stock):
        """Updates the stock level for a given inventory id."""
        conn = get_connection()
        conn.execute("UPDATE inventory SET stock = ? WHERE id = ?", (new_stock, product_id))
        conn.commit()
        conn.close()

    def analyze_query(self, query: str):
        """
        Called by the Coordinator Agent when a user asks a natural
        language question. Looks for a matching product mentioned in the
        query and reports its stock status.
        """
        conn = get_connection()
        rows = conn.execute("SELECT * FROM inventory").fetchall()
        conn.close()

        matched = None
        for row in rows:
            if row["product_name"].lower().split()[0] in query.lower():
                matched = dict(row)
                break

        if matched:
            is_low = matched["stock"] <= matched["minimum_stock"]
            reorder_qty = self.recommend_reorder_quantity(matched) if is_low else 0
            summary = (
                f"{matched['product_name']} stock is {'BELOW' if is_low else 'ABOVE'} minimum "
                f"threshold ({matched['stock']} in stock vs minimum {matched['minimum_stock']}). "
                f"{'Recommended reorder quantity: ' + str(reorder_qty) + ' units.' if is_low else 'No reorder needed right now.'}"
            )
            return {
                "agent": self.name,
                "matched_product": matched["product_name"],
                "is_low_stock": is_low,
                "reorder_quantity": reorder_qty,
                "message": enrich_with_llm(self.name, summary),
            }

        # No specific product mentioned - give an overall summary instead
        low_items = self.detect_low_stock()
        summary = (
            f"No specific product recognized in the query. Currently {len(low_items)} "
            f"product(s) are below minimum stock: "
            f"{', '.join(i['product_name'] for i in low_items) if low_items else 'none'}."
        )
        return {
            "agent": self.name,
            "matched_product": None,
            "is_low_stock": len(low_items) > 0,
            "reorder_quantity": 0,
            "message": enrich_with_llm(self.name, summary),
        }
