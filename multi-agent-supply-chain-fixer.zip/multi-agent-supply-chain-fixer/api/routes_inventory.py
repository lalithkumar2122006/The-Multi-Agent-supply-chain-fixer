"""
api/routes_inventory.py
--------------------------
Endpoints:
    GET  /inventory        -> list all inventory items (+ low stock flag)
    POST /inventory        -> add a new inventory item
    PUT  /inventory/{id}   -> update stock for an item
    DELETE /inventory/{id} -> remove an inventory item
"""

from fastapi import APIRouter, HTTPException
from api.schemas import InventoryCreate, InventoryUpdate
from agents.inventory_agent import InventoryAgent
from database.db import get_connection

router = APIRouter(prefix="/inventory", tags=["Inventory"])
inventory_agent = InventoryAgent()


@router.get("/")
def list_inventory():
    """Returns every inventory item, annotating each with a `is_low_stock` flag."""
    items = inventory_agent.get_all_inventory()
    for item in items:
        item["is_low_stock"] = item["stock"] <= item["minimum_stock"]
    return items


@router.post("/")
def create_inventory(item: InventoryCreate):
    """Adds a brand new product to the inventory table."""
    inventory_agent.add_inventory_item(
        item.product_name, item.stock, item.minimum_stock, item.location
    )
    return {"message": f"Inventory item '{item.product_name}' added successfully."}


@router.put("/{item_id}")
def update_inventory(item_id: int, payload: InventoryUpdate):
    """Updates the stock count for a specific inventory item."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM inventory WHERE id = ?", (item_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Inventory item not found")
    conn.close()

    inventory_agent.update_stock(item_id, payload.stock)
    return {"message": f"Inventory item {item_id} updated to stock={payload.stock}."}


@router.delete("/{item_id}")
def delete_inventory(item_id: int):
    """Deletes an inventory item."""
    conn = get_connection()
    existing = conn.execute("SELECT * FROM inventory WHERE id = ?", (item_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Inventory item not found")
    conn.execute("DELETE FROM inventory WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
    return {"message": f"Inventory item {item_id} deleted."}
