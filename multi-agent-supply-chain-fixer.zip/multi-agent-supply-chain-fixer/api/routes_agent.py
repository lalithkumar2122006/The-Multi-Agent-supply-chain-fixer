"""
api/routes_agent.py
--------------------------
Endpoints:
    POST /ask-agent  -> runs the full multi-agent Coordinator pipeline
    GET  /agent-logs -> returns the real-time agent activity log
                        (used to power the "Agent Activity" / "Agent
                        Collaboration Window" page in the frontend)
"""

from fastapi import APIRouter
from api.schemas import AgentQuery
from agents.coordinator_agent import CoordinatorAgent
from database.db import get_connection

router = APIRouter(tags=["Agents"])
coordinator = CoordinatorAgent()


@router.post("/ask-agent")
def ask_agent(payload: AgentQuery):
    """
    Main multi-agent entry point. Example body:
        { "query": "I have only 20 laptops left." }
    """
    return coordinator.handle_query(payload.query)


@router.get("/agent-logs")
def get_agent_logs(limit: int = 50):
    """Returns the most recent agent activity logs, newest first."""
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM agent_logs ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]
