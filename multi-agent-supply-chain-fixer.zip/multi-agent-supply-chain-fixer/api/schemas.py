"""
api/schemas.py
-----------------
Pydantic models describing the shape of request bodies accepted by the API.
Using explicit schemas gives FastAPI automatic validation + interactive
docs (visible at /docs) for free.
"""

from pydantic import BaseModel
from typing import Optional


class InventoryCreate(BaseModel):
    product_name: str
    stock: int
    minimum_stock: int
    location: str


class InventoryUpdate(BaseModel):
    stock: int


class SupplierCreate(BaseModel):
    supplier_name: str
    rating: float
    delivery_time: int


class ShipmentUpdate(BaseModel):
    status: str


class AgentQuery(BaseModel):
    query: str


class LoginRequest(BaseModel):
    username: str
    password: str
