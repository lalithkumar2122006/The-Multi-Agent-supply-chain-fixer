"""
api/routes_shipments.py
--------------------------
Endpoints:
    GET /shipments          -> list all shipments
    PUT /shipments/{id}     -> update shipment status
"""

from fastapi import APIRouter, HTTPException
from api.schemas import ShipmentUpdate
from agents.logistics_agent import LogisticsAgent
from database.db import get_connection

router = APIRouter(prefix="/shipments", tags=["Shipments"])
logistics_agent = LogisticsAgent()


@router.get("/")
def list_shipments():
    return logistics_agent.get_all_shipments()


@router.put("/{shipment_id}")
def update_shipment(shipment_id: int, payload: ShipmentUpdate):
    conn = get_connection()
    existing = conn.execute("SELECT * FROM shipments WHERE id = ?", (shipment_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Shipment not found")
    conn.close()

    logistics_agent.update_status(shipment_id, payload.status)
    return {"message": f"Shipment {shipment_id} status updated to '{payload.status}'."}
