"""
api/routes_auth.py
--------------------------
Endpoints:
    POST /login -> validates username/password against the `users` table

This is intentionally simple (no JWT/session store) since the brief calls
for a basic "User Login" feature for a demo/portfolio project. For a real
production deployment you would add hashed passwords + JWT tokens.
"""

from fastapi import APIRouter, HTTPException
from api.schemas import LoginRequest
from database.db import get_connection

router = APIRouter(tags=["Auth"])


@router.post("/login")
def login(payload: LoginRequest):
    conn = get_connection()
    user = conn.execute(
        "SELECT * FROM users WHERE username = ? AND password = ?",
        (payload.username, payload.password),
    ).fetchone()
    conn.close()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password")

    return {"message": "Login successful", "username": user["username"]}
