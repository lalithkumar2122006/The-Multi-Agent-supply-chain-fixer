"""
api/routes_risk.py
--------------------------
Endpoints:
    GET /risk -> list all recorded risks plus the live composite risk score
"""

from fastapi import APIRouter
from agents.risk_agent import RiskAgent

router = APIRouter(prefix="/risk", tags=["Risk"])
risk_agent = RiskAgent()


@router.get("/")
def list_risk():
    return {
        "risks": risk_agent.get_all_risks(),
        "overall": risk_agent.calculate_risk_score(),
    }
