"""
api/routes_suppliers.py
--------------------------
Endpoints:
    GET  /suppliers       -> list all suppliers, ranked by performance score
    POST /suppliers       -> add a new supplier
    DELETE /suppliers/{id}-> remove a supplier
"""

from fastapi import APIRouter, HTTPException
from api.schemas import SupplierCreate
from agents.supplier_agent import SupplierAgent
from database.db import get_connection

router = APIRouter(prefix="/suppliers", tags=["Suppliers"])
supplier_agent = SupplierAgent()


@router.get("/")
def list_suppliers():
    """Returns every supplier, ranked best -> worst using the Supplier Agent's scoring model."""
    return supplier_agent.rank_suppliers()


@router.post("/")
def create_supplier(supplier: SupplierCreate):
    conn = get_connection()
    conn.execute(
        "INSERT INTO suppliers (supplier_name, rating, delivery_time) VALUES (?, ?, ?)",
        (supplier.supplier_name, supplier.rating, supplier.delivery_time),
    )
    conn.commit()
    conn.close()
    return {"message": f"Supplier '{supplier.supplier_name}' added successfully."}


@router.delete("/{supplier_id}")
def delete_supplier(supplier_id: int):
    conn = get_connection()
    existing = conn.execute("SELECT * FROM suppliers WHERE id = ?", (supplier_id,)).fetchone()
    if not existing:
        conn.close()
        raise HTTPException(status_code=404, detail="Supplier not found")
    conn.execute("DELETE FROM suppliers WHERE id = ?", (supplier_id,))
    conn.commit()
    conn.close()
    return {"message": f"Supplier {supplier_id} deleted."}
