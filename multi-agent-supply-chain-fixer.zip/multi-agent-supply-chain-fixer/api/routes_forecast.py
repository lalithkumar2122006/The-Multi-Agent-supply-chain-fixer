"""
api/routes_forecast.py
--------------------------
Endpoints:
    GET /forecast -> list predicted demand for every product, with spike flags
"""

from fastapi import APIRouter
from agents.forecast_agent import ForecastAgent

router = APIRouter(prefix="/forecast", tags=["Forecast"])
forecast_agent = ForecastAgent()


@router.get("/")
def list_forecast():
    forecasts = forecast_agent.get_all_forecasts()
    for f in forecasts:
        spike_info = forecast_agent.detect_spike(f["product"])
        f["spike_percent"] = spike_info["spike_percent"] if spike_info else 0
        f["is_spike"] = spike_info["is_spike"] if spike_info else False
    return forecasts
