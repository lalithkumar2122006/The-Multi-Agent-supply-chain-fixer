"""
database/seed.py
------------------
Populates the database with realistic sample data the very first time
the app runs, so the dashboard, charts and agents have something to work
with immediately (no manual data entry required).
"""

from database.db import get_connection


def seed_if_empty():
    """
    Inserts sample rows into every table, but ONLY if that table is
    currently empty. This makes the function safe to call on every
    server restart without duplicating data.
    """
    conn = get_connection()
    cur = conn.cursor()

    # ---------------- Inventory ----------------
    cur.execute("SELECT COUNT(*) FROM inventory")
    if cur.fetchone()[0] == 0:
        inventory_data = [
            ("Laptops", 20, 50, "Warehouse A"),
            ("Wireless Mouse", 340, 100, "Warehouse A"),
            ("Mechanical Keyboards", 85, 60, "Warehouse B"),
            ("27-inch Monitors", 45, 40, "Warehouse B"),
            ("USB-C Hubs", 12, 30, "Warehouse C"),
            ("Office Chairs", 150, 50, "Warehouse C"),
            ("Webcams", 8, 25, "Warehouse A"),
            ("Server Racks", 6, 10, "Warehouse D"),
        ]
        cur.executemany(
            "INSERT INTO inventory (product_name, stock, minimum_stock, location) VALUES (?, ?, ?, ?)",
            inventory_data,
        )

    # ---------------- Suppliers ----------------
    cur.execute("SELECT COUNT(*) FROM suppliers")
    if cur.fetchone()[0] == 0:
        supplier_data = [
            ("Supplier A - TechSource Global", 4.8, 2),
            ("Supplier B - Pacific Components", 4.2, 4),
            ("Supplier C - Rapid Electronics", 3.6, 6),
            ("Supplier D - Continental Parts", 4.5, 3),
            ("Supplier E - Budget Hardware Co", 3.1, 9),
        ]
        cur.executemany(
            "INSERT INTO suppliers (supplier_name, rating, delivery_time) VALUES (?, ?, ?)",
            supplier_data,
        )

    # ---------------- Orders ----------------
    cur.execute("SELECT COUNT(*) FROM orders")
    if cur.fetchone()[0] == 0:
        order_data = [
            ("Laptops", 100, "Pending"),
            ("Wireless Mouse", 200, "Delivered"),
            ("Mechanical Keyboards", 50, "Processing"),
            ("Webcams", 40, "Pending"),
            ("Server Racks", 10, "Pending"),
        ]
        cur.executemany(
            "INSERT INTO orders (product, quantity, status) VALUES (?, ?, ?)",
            order_data,
        )

    # ---------------- Shipments ----------------
    cur.execute("SELECT COUNT(*) FROM shipments")
    if cur.fetchone()[0] == 0:
        shipment_data = [
            ("TRK1001", "Chennai Hub", "In Transit"),
            ("TRK1002", "Mumbai Hub", "Delayed"),
            ("TRK1003", "Delhi Hub", "Delivered"),
            ("TRK1004", "Bangalore Hub", "Delayed"),
            ("TRK1005", "Coimbatore Hub", "In Transit"),
            ("TRK1006", "Hyderabad Hub", "Delivered"),
        ]
        cur.executemany(
            "INSERT INTO shipments (tracking_id, location, status) VALUES (?, ?, ?)",
            shipment_data,
        )

    # ---------------- Forecast ----------------
    cur.execute("SELECT COUNT(*) FROM forecast")
    if cur.fetchone()[0] == 0:
        forecast_data = [
            ("Laptops", 150),
            ("Wireless Mouse", 400),
            ("Mechanical Keyboards", 120),
            ("27-inch Monitors", 60),
            ("USB-C Hubs", 90),
            ("Webcams", 70),
        ]
        cur.executemany(
            "INSERT INTO forecast (product, predicted_demand) VALUES (?, ?)",
            forecast_data,
        )

    # ---------------- Risks ----------------
    cur.execute("SELECT COUNT(*) FROM risks")
    if cur.fetchone()[0] == 0:
        risk_data = [
            ("Stock Shortage", "High", "Reorder Laptops and Webcams immediately from Supplier A."),
            ("Supplier Delay", "Medium", "Switch backup orders to Supplier D for faster delivery."),
            ("Shipment Delay", "Medium", "Reroute TRK1002 and TRK1004 through express logistics partner."),
            ("Demand Spike", "High", "Increase forecasted stock for Wireless Mouse by 40%."),
        ]
        cur.executemany(
            "INSERT INTO risks (risk_type, severity, solution) VALUES (?, ?, ?)",
            risk_data,
        )

    # ---------------- Default user (username: admin / password: admin123) ----------------
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            ("admin", "admin123"),
        )

    conn.commit()
    conn.close()
