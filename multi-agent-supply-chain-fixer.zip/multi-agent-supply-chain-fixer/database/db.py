"""
database/db.py
----------------
Central database module for the Multi-Agent Supply Chain Fixer.

Responsible for:
- Creating a SQLite database file (supply_chain.db)
- Creating all required tables if they do not already exist
- Providing a simple connection helper used by every API route / agent
"""

import sqlite3
import os

# The database file lives inside the /database folder so it is easy to find,
# back up, or delete during development.
DB_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(DB_DIR, "supply_chain.db")


def get_connection():
    """
    Returns a new SQLite connection.
    `check_same_thread=False` allows FastAPI (which may use different
    threads for different requests) to safely share the same DB file.
    `row_factory` lets us access columns by name (row["product_name"]).
    """
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """
    Creates every table used by the application if it does not exist yet.
    This function is safe to call every time the server starts.
    """
    conn = get_connection()
    cur = conn.cursor()

    # ---------------- Inventory table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            stock INTEGER NOT NULL,
            minimum_stock INTEGER NOT NULL,
            location TEXT NOT NULL
        )
    """)

    # ---------------- Suppliers table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS suppliers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            supplier_name TEXT NOT NULL,
            rating REAL NOT NULL,
            delivery_time INTEGER NOT NULL
        )
    """)

    # ---------------- Orders table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            status TEXT NOT NULL
        )
    """)

    # ---------------- Shipments table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS shipments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tracking_id TEXT NOT NULL,
            location TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    # ---------------- Forecast table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS forecast (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product TEXT NOT NULL,
            predicted_demand INTEGER NOT NULL
        )
    """)

    # ---------------- Risks table ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS risks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            risk_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            solution TEXT NOT NULL
        )
    """)

    # ---------------- Users table (simple login) ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # ---------------- Agent Logs table (real-time agent activity) ----------------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_name TEXT NOT NULL,
            message TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()
