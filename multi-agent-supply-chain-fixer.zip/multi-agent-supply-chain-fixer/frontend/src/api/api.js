// api/api.js
// -----------------------------------------------------------
// Central Axios instance + typed helper functions for every
// backend endpoint. Every page imports from here instead of
// calling axios directly, so the base URL only lives in one place.
// -----------------------------------------------------------
import axios from "axios";

// The FastAPI backend runs on port 8000 by default (uvicorn main:app --reload)
export const BASE_URL = "http://127.0.0.1:8000";

const client = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
});

// ---------------- Inventory ----------------
export const getInventory = () => client.get("/inventory/");
export const addInventory = (item) => client.post("/inventory/", item);
export const updateInventoryStock = (id, stock) => client.put(`/inventory/${id}`, { stock });
export const deleteInventory = (id) => client.delete(`/inventory/${id}`);

// ---------------- Suppliers ----------------
export const getSuppliers = () => client.get("/suppliers/");
export const addSupplier = (supplier) => client.post("/suppliers/", supplier);
export const deleteSupplier = (id) => client.delete(`/suppliers/${id}`);

// ---------------- Shipments ----------------
export const getShipments = () => client.get("/shipments/");
export const updateShipmentStatus = (id, status) => client.put(`/shipments/${id}`, { status });

// ---------------- Forecast ----------------
export const getForecast = () => client.get("/forecast/");

// ---------------- Risk ----------------
export const getRisk = () => client.get("/risk/");

// ---------------- Agents ----------------
export const askAgent = (query) => client.post("/ask-agent", { query });
export const getAgentLogs = (limit = 50) => client.get(`/agent-logs?limit=${limit}`);

// ---------------- Auth ----------------
export const login = (username, password) => client.post("/login", { username, password });

export default client;
