// context/ThemeContext.js
// -----------------------------------------------------------
// Provides app-wide dark/light theme state via React Context.
// The chosen theme is written to document.documentElement's
// `data-theme` attribute, which our CSS variables (theme.css)
// key off of.
// -----------------------------------------------------------
import React, { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  // Default to dark mode, but remember the user's last choice.
  const [theme, setTheme] = useState(
    () => localStorage.getItem("scf-theme") || "dark"
  );

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("scf-theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}
