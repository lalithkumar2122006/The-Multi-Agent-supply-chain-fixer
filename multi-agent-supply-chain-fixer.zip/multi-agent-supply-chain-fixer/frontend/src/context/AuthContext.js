// context/AuthContext.js
// -----------------------------------------------------------
// Minimal client-side auth state, backed by the /login API route.
// Stores the logged-in username in localStorage so a page refresh
// doesn't log the user out during the demo.
// -----------------------------------------------------------
import React, { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => localStorage.getItem("scf-user"));

  const login = (username) => {
    localStorage.setItem("scf-user", username);
    setUser(username);
  };

  const logout = () => {
    localStorage.removeItem("scf-user");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
