// index.js
// -----------------------------------------------------------
// Application entry point. Mounts <App /> into the #root div
// and imports the global theme tokens (CSS variables).
// -----------------------------------------------------------
import React from "react";
import ReactDOM from "react-dom/client";
import "./styles/theme.css";
import App from "./App";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
