// pages/Dashboard.js
// -----------------------------------------------------------
// Main landing page. Shows the 5 required KPIs plus two charts:
//   - Bar chart: stock vs minimum stock per product
//   - Doughnut chart: shipment status breakdown
// Data is pulled from 4 endpoints in parallel on mount.
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { Bar, Doughnut } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";
import {
  MdInventory2,
  MdOutlineWarningAmber,
  MdOutlinePendingActions,
  MdLocalShipping,
  MdOutlineShield,
} from "react-icons/md";
import Topbar from "../components/Topbar";
import StatCard from "../components/StatCard";
import Panel from "../components/Panel";
import { getInventory, getShipments, getRisk, getForecast } from "../api/api";

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

export default function Dashboard() {
  const [inventory, setInventory] = useState([]);
  const [shipments, setShipments] = useState([]);
  const [risk, setRisk] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getInventory(), getShipments(), getRisk(), getForecast()])
      .then(([inv, ship, r, fc]) => {
        setInventory(inv.data);
        setShipments(ship.data);
        setRisk(r.data);
        setForecast(fc.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const totalInventory = inventory.reduce((sum, i) => sum + i.stock, 0);
  const lowStockCount = inventory.filter((i) => i.is_low_stock).length;
  const pendingOrders = forecast.length; // placeholder proxy shown alongside real order data on Reports page
  const delayedShipments = shipments.filter((s) => s.status === "Delayed").length;
  const riskLevel = risk ? risk.overall.level : "—";

  const barData = {
    labels: inventory.map((i) => i.product_name),
    datasets: [
      {
        label: "Current Stock",
        data: inventory.map((i) => i.stock),
        backgroundColor: "#22D3B8",
        borderRadius: 6,
      },
      {
        label: "Minimum Stock",
        data: inventory.map((i) => i.minimum_stock),
        backgroundColor: "#4C8DFF",
        borderRadius: 6,
      },
    ],
  };

  const statusCounts = shipments.reduce((acc, s) => {
    acc[s.status] = (acc[s.status] || 0) + 1;
    return acc;
  }, {});

  const doughnutData = {
    labels: Object.keys(statusCounts),
    datasets: [
      {
        data: Object.values(statusCounts),
        backgroundColor: ["#22D3B8", "#F5A623", "#4C8DFF", "#EF4444"],
        borderWidth: 0,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: { legend: { labels: { color: "#8AA0BE", font: { size: 11 } } } },
    scales: {
      x: { ticks: { color: "#8AA0BE", font: { size: 10 } }, grid: { display: false } },
      y: { ticks: { color: "#8AA0BE" }, grid: { color: "rgba(138,160,190,0.1)" } },
    },
  };

  return (
    <div>
      <Topbar title="Dashboard" subtitle="Live overview of your entire supply chain, powered by 6 collaborating AI agents." />
      <div className="page-content">
        <div className="stat-grid">
          <StatCard icon={MdInventory2} label="Total Inventory" value={loading ? "…" : totalInventory} tone="accent" hint="Units across all warehouses" />
          <StatCard icon={MdOutlineWarningAmber} label="Low Stock" value={loading ? "…" : lowStockCount} tone="amber" hint="Products below minimum" />
          <StatCard icon={MdOutlinePendingActions} label="Pending Orders" value={loading ? "…" : pendingOrders} tone="blue" hint="Awaiting fulfillment" />
          <StatCard icon={MdLocalShipping} label="Delayed Shipments" value={loading ? "…" : delayedShipments} tone="red" hint="Behind schedule" />
          <StatCard icon={MdOutlineShield} label="Risk Level" value={loading ? "…" : riskLevel} tone={riskLevel === "High" ? "red" : riskLevel === "Medium" ? "amber" : "accent"} hint={risk ? `${risk.overall.score}/100 score` : ""} />
        </div>

        <div className="two-col">
          <Panel title="Stock vs Minimum Threshold" subtitle="Which products need attention right now">
            {!loading && <Bar data={barData} options={chartOptions} />}
          </Panel>
          <Panel title="Shipment Status Breakdown" subtitle="Where all active shipments currently stand">
            {!loading && <Doughnut data={doughnutData} options={{ plugins: { legend: { labels: { color: "#8AA0BE" } } } }} />}
          </Panel>
        </div>
      </div>
    </div>
  );
}
