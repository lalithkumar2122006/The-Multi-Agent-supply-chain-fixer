// pages/Suppliers.js
// -----------------------------------------------------------
// Lists suppliers ranked by the Supplier Agent's performance
// score, and lets the user add or remove suppliers.
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { MdAdd, MdDelete, MdStar } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getSuppliers, addSupplier, deleteSupplier } from "../api/api";

const emptyForm = { supplier_name: "", rating: "", delivery_time: "" };

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);

  const load = () => {
    setLoading(true);
    getSuppliers().then((res) => setSuppliers(res.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!form.supplier_name || form.rating === "" || form.delivery_time === "") return;
    await addSupplier({
      supplier_name: form.supplier_name,
      rating: Number(form.rating),
      delivery_time: Number(form.delivery_time),
    });
    setForm(emptyForm);
    load();
  };

  const handleDelete = async (id) => {
    await deleteSupplier(id);
    load();
  };

  return (
    <div>
      <Topbar title="Suppliers" subtitle="Ranked live by the Supplier Agent (70% rating, 30% delivery speed)." />
      <div className="page-content">
        <Panel title="Add Supplier">
          <form className="inline-form" onSubmit={handleAdd}>
            <input className="form-input" placeholder="Supplier name" value={form.supplier_name}
              onChange={(e) => setForm({ ...form, supplier_name: e.target.value })} />
            <input className="form-input" placeholder="Rating (0-5)" type="number" step="0.1" value={form.rating}
              onChange={(e) => setForm({ ...form, rating: e.target.value })} />
            <input className="form-input" placeholder="Delivery time (days)" type="number" value={form.delivery_time}
              onChange={(e) => setForm({ ...form, delivery_time: e.target.value })} />
            <button className="btn-primary" type="submit"><MdAdd size={16} /> Add</button>
          </form>
        </Panel>

        <Panel title="Supplier Rankings" subtitle={loading ? "Loading…" : `${suppliers.length} suppliers evaluated`}>
          <table>
            <thead>
              <tr><th>Rank</th><th>Supplier</th><th>Rating</th><th>Delivery Time</th><th>Score</th><th></th></tr>
            </thead>
            <tbody>
              {suppliers.map((s, idx) => (
                <tr key={s.id}>
                  <td>#{idx + 1}</td>
                  <td>{s.supplier_name} {idx === 0 && <MdStar color="var(--amber)" style={{ verticalAlign: "middle", marginLeft: 4 }} />}</td>
                  <td>{s.rating} / 5</td>
                  <td>{s.delivery_time} days</td>
                  <td>
                    <span className={`badge ${s.score > 0.7 ? "badge-low" : s.score > 0.5 ? "badge-medium" : "badge-high"}`}>
                      {(s.score * 100).toFixed(1)}%
                    </span>
                  </td>
                  <td>
                    <button className="icon-btn danger" onClick={() => handleDelete(s.id)}><MdDelete size={15} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
