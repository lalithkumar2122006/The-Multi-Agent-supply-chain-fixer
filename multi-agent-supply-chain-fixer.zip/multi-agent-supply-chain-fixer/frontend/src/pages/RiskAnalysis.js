// pages/RiskAnalysis.js
// -----------------------------------------------------------
// Shows the Risk Agent's composite score plus a "heatmap" style
// grid of individual risk factors and recorded risks + solutions.
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { MdOutlineWarningAmber } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getRisk } from "../api/api";
import "./RiskAnalysis.css";

function severityClass(sev) {
  const s = sev.toLowerCase();
  if (s === "high") return "badge-high";
  if (s === "medium") return "badge-medium";
  return "badge-low";
}

// Turns a 0-100 ratio into one of 5 heat buckets (for the heatmap cells)
function heatBucket(value) {
  if (value >= 70) return "heat-5";
  if (value >= 50) return "heat-4";
  if (value >= 30) return "heat-3";
  if (value >= 10) return "heat-2";
  return "heat-1";
}

export default function RiskAnalysis() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRisk().then((res) => setData(res.data)).finally(() => setLoading(false));
  }, []);

  const overall = data?.overall;
  const factors = overall
    ? [
        { label: "Low Stock Products", value: overall.low_stock_ratio },
        { label: "Delayed Shipments", value: overall.delayed_ratio },
        { label: "Underperforming Suppliers", value: overall.weak_supplier_ratio },
      ]
    : [];

  return (
    <div>
      <Topbar title="Risk Analysis" subtitle="Composite risk score generated live by the Risk Analysis Agent." />
      <div className="page-content">
        <div className="two-col">
          <Panel title="Overall Risk Score" action={<MdOutlineWarningAmber size={20} color="var(--text-muted)" />}>
            {!loading && overall && (
              <div className="risk-score-block">
                <div className={`risk-ring ${overall.level.toLowerCase()}`}>
                  <span>{overall.score}</span>
                  <small>/ 100</small>
                </div>
                <span className={`badge ${severityClass(overall.level)}`} style={{ marginTop: 12 }}>
                  {overall.level} Risk
                </span>
              </div>
            )}
          </Panel>

          <Panel title="Risk Factor Heatmap" subtitle="Share of the supply chain currently affected">
            <div className="heatmap-grid">
              {factors.map((f) => (
                <div key={f.label} className={`heat-cell ${heatBucket(f.value)}`}>
                  <p className="heat-value">{f.value}%</p>
                  <p className="heat-label">{f.label}</p>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <Panel title="Recorded Risks & Recommended Solutions" subtitle={loading ? "Loading…" : `${data?.risks.length || 0} risks on file`}>
          <table>
            <thead><tr><th>Risk Type</th><th>Severity</th><th>Recommended Solution</th></tr></thead>
            <tbody>
              {data?.risks.map((r) => (
                <tr key={r.id}>
                  <td>{r.risk_type}</td>
                  <td><span className={`badge ${severityClass(r.severity)}`}>{r.severity}</span></td>
                  <td>{r.solution}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
