// pages/AgentActivity.js
// -----------------------------------------------------------
// This is the centerpiece page: the user types a natural language
// supply chain question, the Coordinator Agent runs the full
// pipeline (Inventory -> Supplier -> Logistics -> Forecast -> Risk),
// and this page visualizes the hand-off between agents as an
// animated "route line" (this project's signature visual motif -
// tying together the logistics/supply-chain theme with the idea
// of a signal travelling node to node) plus a real-time log feed.
// -----------------------------------------------------------
import React, { useEffect, useRef, useState } from "react";
import {
  MdOutlineHub,
  MdInventory2,
  MdOutlinePeopleAlt,
  MdLocalShipping,
  MdOutlineShowChart,
  MdOutlineWarningAmber,
  MdSend,
} from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { askAgent, getAgentLogs } from "../api/api";
import "./AgentActivity.css";

const NODES = [
  { key: "coordinator", label: "Coordinator", icon: MdOutlineHub },
  { key: "inventory", label: "Inventory", icon: MdInventory2 },
  { key: "supplier", label: "Supplier", icon: MdOutlinePeopleAlt },
  { key: "logistics", label: "Logistics", icon: MdLocalShipping },
  { key: "forecast", label: "Forecast", icon: MdOutlineShowChart },
  { key: "risk", label: "Risk", icon: MdOutlineWarningAmber },
];

const EXAMPLE_QUERIES = [
  "I have only 20 laptops left.",
  "Webcams are running low, what should we do?",
  "Is there any risk with our current suppliers?",
];

export default function AgentActivity() {
  const [query, setQuery] = useState("");
  const [running, setRunning] = useState(false);
  const [activeStep, setActiveStep] = useState(-1); // -1 = idle
  const [result, setResult] = useState(null);
  const [logs, setLogs] = useState([]);
  const pollRef = useRef(null);

  const loadLogs = () => {
    getAgentLogs(30).then((res) => setLogs(res.data));
  };

  useEffect(() => {
    loadLogs();
    // Poll every 4s so the log feed feels "real-time" without needing websockets
    pollRef.current = setInterval(loadLogs, 4000);
    return () => clearInterval(pollRef.current);
  }, []);

  const runPipeline = async (e) => {
    e.preventDefault();
    if (!query.trim() || running) return;
    setRunning(true);
    setResult(null);
    setActiveStep(0);

    // Animate the pipeline node-by-node while the real request is in flight
    const stepTimer = setInterval(() => {
      setActiveStep((prev) => (prev < NODES.length - 1 ? prev + 1 : prev));
    }, 450);

    try {
      const res = await askAgent(query);
      setResult(res.data);
      loadLogs();
    } finally {
      clearInterval(stepTimer);
      setTimeout(() => {
        setActiveStep(-1);
        setRunning(false);
      }, NODES.length * 450 + 200);
    }
  };

  return (
    <div>
      <Topbar title="Agent Activity" subtitle="Watch the 6 AI agents collaborate on a live query, end to end." />
      <div className="page-content">
        <Panel title="Ask the Agent Crew">
          <form className="ask-form" onSubmit={runPipeline}>
            <input
              className="form-input"
              placeholder='e.g. "I have only 20 laptops left."'
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button className="btn-primary" type="submit" disabled={running}>
              <MdSend size={15} /> {running ? "Running…" : "Run"}
            </button>
          </form>
          <div className="example-row">
            {EXAMPLE_QUERIES.map((q) => (
              <button key={q} type="button" className="example-chip" onClick={() => setQuery(q)}>
                {q}
              </button>
            ))}
          </div>
        </Panel>

        <Panel title="Agent Pipeline" subtitle="Coordinator → Inventory → Supplier → Logistics → Forecast → Risk → Coordinator">
          <div className="pipeline">
            {NODES.map((node, idx) => {
              const Icon = node.icon;
              const isActive = activeStep === idx;
              const isDone = activeStep > idx || (activeStep === -1 && result);
              return (
                <React.Fragment key={node.key}>
                  <div className={`pipe-node ${isActive ? "active" : ""} ${isDone ? "done" : ""}`}>
                    <div className="pipe-icon"><Icon size={20} /></div>
                    <span>{node.label}</span>
                  </div>
                  {idx < NODES.length - 1 && (
                    <div className={`pipe-line ${activeStep > idx || (activeStep === -1 && result) ? "flowing" : ""}`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </Panel>

        {result && (
          <Panel title="Final Recommendation" className="recommendation-panel">
            <p className="final-rec">{result.final_recommendation}</p>
            <div className="agent-outputs">
              {result.pipeline.map((step) => (
                <div key={step.agent} className="agent-output-card">
                  <p className="agent-output-name">{step.agent}</p>
                  <p className="agent-output-msg">{step.message}</p>
                </div>
              ))}
            </div>
          </Panel>
        )}

        <Panel title="Real-Time Agent Logs" subtitle="Every action taken by every agent, most recent first">
          <div className="log-feed">
            {logs.length === 0 && <p className="log-empty">No agent activity yet. Run a query above to get started.</p>}
            {logs.map((log) => (
              <div key={log.id} className="log-row">
                <span className="log-agent">{log.agent_name}</span>
                <span className="log-msg">{log.message}</span>
                <span className="log-time">{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
