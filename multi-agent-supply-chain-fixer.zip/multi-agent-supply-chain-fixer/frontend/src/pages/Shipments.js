// pages/Shipments.js
// -----------------------------------------------------------
// Shipment tracking page. Lets the Logistics Agent's findings
// (delayed shipments) be visible and actionable - status can be
// updated directly (e.g. mark as "In Transit" after rerouting).
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { MdLocalShipping } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getShipments, updateShipmentStatus } from "../api/api";

const STATUS_OPTIONS = ["In Transit", "Delayed", "Delivered"];

function badgeClass(status) {
  if (status === "Delayed") return "badge-delayed";
  if (status === "Delivered") return "badge-delivered";
  return "badge-transit";
}

export default function Shipments() {
  const [shipments, setShipments] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    getShipments().then((res) => setShipments(res.data)).finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleStatusChange = async (id, status) => {
    await updateShipmentStatus(id, status);
    load();
  };

  return (
    <div>
      <Topbar title="Shipments" subtitle="Tracked by the Logistics Agent, which flags delays and suggests express routes." />
      <div className="page-content">
        <Panel title="Active Shipments" subtitle={loading ? "Loading…" : `${shipments.length} shipments in the network`}
          action={<MdLocalShipping size={20} color="var(--text-muted)" />}>
          <table>
            <thead>
              <tr><th>Tracking ID</th><th>Location</th><th>Status</th><th>Update Status</th></tr>
            </thead>
            <tbody>
              {shipments.map((s) => (
                <tr key={s.id}>
                  <td className="mono">{s.tracking_id}</td>
                  <td>{s.location}</td>
                  <td><span className={`badge ${badgeClass(s.status)}`}>{s.status}</span></td>
                  <td>
                    <select className="form-input" value={s.status} style={{ width: 160 }}
                      onChange={(e) => handleStatusChange(s.id, e.target.value)}>
                      {STATUS_OPTIONS.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
