// pages/Login.js
// -----------------------------------------------------------
// Simple login screen backed by POST /login.
// Default demo credentials: admin / admin123 (seeded automatically).
// -----------------------------------------------------------
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MdLockOutline } from "react-icons/md";
import { login as loginApi } from "../api/api";
import { useAuth } from "../context/AuthContext";
import "./Login.css";

export default function Login() {
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("admin123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await loginApi(username, password);
      login(res.data.username);
      navigate("/");
    } catch (err) {
      setError("Invalid username or password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-icon"><MdLockOutline size={22} /></div>
        <h2>Welcome back</h2>
        <p className="login-subtitle">Sign in to the Multi-Agent Supply Chain Fixer</p>

        <form onSubmit={handleSubmit} className="login-form">
          <label>Username</label>
          <input className="form-input" value={username} onChange={(e) => setUsername(e.target.value)} />
          <label>Password</label>
          <input className="form-input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <p className="login-error">{error}</p>}
          <button className="btn-primary" type="submit" disabled={loading} style={{ marginTop: 8 }}>
            {loading ? "Signing in…" : "Sign In"}
          </button>
        </form>
        <p className="login-hint">Demo credentials: <span className="mono">admin / admin123</span></p>
      </div>
    </div>
  );
}
