// pages/Inventory.js
// -----------------------------------------------------------
// Full CRUD page for the inventory table:
//   - list all products with low-stock badges
//   - add a new product
//   - inline-edit stock count
//   - delete a product
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { MdAdd, MdDelete, MdEdit, MdCheck, MdClose } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getInventory, addInventory, updateInventoryStock, deleteInventory } from "../api/api";

const emptyForm = { product_name: "", stock: "", minimum_stock: "", location: "" };

export default function Inventory() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState("");

  const load = () => {
    setLoading(true);
    getInventory()
      .then((res) => setItems(res.data))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!form.product_name || form.stock === "" || form.minimum_stock === "" || !form.location) return;
    await addInventory({
      product_name: form.product_name,
      stock: Number(form.stock),
      minimum_stock: Number(form.minimum_stock),
      location: form.location,
    });
    setForm(emptyForm);
    load();
  };

  const startEdit = (item) => {
    setEditingId(item.id);
    setEditValue(item.stock);
  };

  const saveEdit = async (id) => {
    await updateInventoryStock(id, Number(editValue));
    setEditingId(null);
    load();
  };

  const handleDelete = async (id) => {
    await deleteInventory(id);
    load();
  };

  return (
    <div>
      <Topbar title="Inventory" subtitle="Monitored continuously by the Inventory Agent." />
      <div className="page-content">
        <Panel title="Add Product">
          <form className="inline-form" onSubmit={handleAdd}>
            <input className="form-input" placeholder="Product name" value={form.product_name}
              onChange={(e) => setForm({ ...form, product_name: e.target.value })} />
            <input className="form-input" placeholder="Stock" type="number" value={form.stock}
              onChange={(e) => setForm({ ...form, stock: e.target.value })} />
            <input className="form-input" placeholder="Minimum stock" type="number" value={form.minimum_stock}
              onChange={(e) => setForm({ ...form, minimum_stock: e.target.value })} />
            <input className="form-input" placeholder="Location" value={form.location}
              onChange={(e) => setForm({ ...form, location: e.target.value })} />
            <button className="btn-primary" type="submit"><MdAdd size={16} /> Add</button>
          </form>
        </Panel>

        <Panel title="All Products" subtitle={loading ? "Loading…" : `${items.length} products tracked`}>
          <table>
            <thead>
              <tr>
                <th>Product</th><th>Stock</th><th>Minimum</th><th>Location</th><th>Status</th><th></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td>{item.product_name}</td>
                  <td>
                    {editingId === item.id ? (
                      <input className="form-input" style={{ width: 80 }} value={editValue}
                        onChange={(e) => setEditValue(e.target.value)} type="number" />
                    ) : (
                      item.stock
                    )}
                  </td>
                  <td>{item.minimum_stock}</td>
                  <td>{item.location}</td>
                  <td>
                    <span className={`badge ${item.is_low_stock ? "badge-high" : "badge-low"}`}>
                      {item.is_low_stock ? "Low Stock" : "Healthy"}
                    </span>
                  </td>
                  <td style={{ display: "flex", gap: 6 }}>
                    {editingId === item.id ? (
                      <>
                        <button className="icon-btn" onClick={() => saveEdit(item.id)}><MdCheck size={15} /></button>
                        <button className="icon-btn" onClick={() => setEditingId(null)}><MdClose size={15} /></button>
                      </>
                    ) : (
                      <>
                        <button className="icon-btn" onClick={() => startEdit(item)}><MdEdit size={15} /></button>
                        <button className="icon-btn danger" onClick={() => handleDelete(item.id)}><MdDelete size={15} /></button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
