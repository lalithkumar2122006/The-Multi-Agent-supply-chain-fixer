// pages/Reports.js
// -----------------------------------------------------------
// A consolidated, printable-style report combining data from every
// domain: inventory, suppliers, shipments, forecast and risk -
// useful as an export-ready summary for supply chain managers.
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { MdOutlineDescription, MdOutlinePrint } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getInventory, getSuppliers, getShipments, getForecast, getRisk } from "../api/api";

export default function Reports() {
  const [data, setData] = useState(null);

  useEffect(() => {
    Promise.all([getInventory(), getSuppliers(), getShipments(), getForecast(), getRisk()]).then(
      ([inv, sup, ship, fc, risk]) => {
        setData({
          inventory: inv.data,
          suppliers: sup.data,
          shipments: ship.data,
          forecast: fc.data,
          risk: risk.data,
        });
      }
    );
  }, []);

  if (!data) {
    return (
      <div>
        <Topbar title="Reports" subtitle="Consolidated supply chain report." />
        <div className="page-content"><Panel>Loading report…</Panel></div>
      </div>
    );
  }

  const lowStock = data.inventory.filter((i) => i.is_low_stock);
  const delayed = data.shipments.filter((s) => s.status === "Delayed");
  const bestSupplier = data.suppliers[0];
  const spikes = data.forecast.filter((f) => f.is_spike);

  return (
    <div>
      <Topbar title="Reports" subtitle="A consolidated snapshot of your entire supply chain, generated from live agent data." />
      <div className="page-content">
        <Panel
          title="Executive Summary"
          action={
            <button className="icon-btn" onClick={() => window.print()} title="Print report">
              <MdOutlinePrint size={16} />
            </button>
          }
        >
          <ul className="report-list">
            <li><strong>{data.inventory.length}</strong> products tracked across all warehouses; <strong>{lowStock.length}</strong> currently below minimum stock.</li>
            <li>Top-ranked supplier: <strong>{bestSupplier?.supplier_name || "—"}</strong> ({bestSupplier ? (bestSupplier.score * 100).toFixed(1) : "—"}% score).</li>
            <li><strong>{delayed.length}</strong> shipment(s) currently delayed out of {data.shipments.length} tracked.</li>
            <li><strong>{spikes.length}</strong> product(s) forecasted to see a significant demand spike.</li>
            <li>Overall supply chain risk: <strong>{data.risk.overall.level}</strong> ({data.risk.overall.score}/100).</li>
          </ul>
        </Panel>

        <div className="two-col">
          <Panel title="Low Stock Products" action={<MdOutlineDescription size={18} color="var(--text-muted)" />}>
            {lowStock.length === 0 ? <p className="log-empty">No low stock products. Great job!</p> : (
              <table>
                <thead><tr><th>Product</th><th>Stock</th><th>Minimum</th></tr></thead>
                <tbody>
                  {lowStock.map((i) => (
                    <tr key={i.id}><td>{i.product_name}</td><td>{i.stock}</td><td>{i.minimum_stock}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
          </Panel>

          <Panel title="Delayed Shipments">
            {delayed.length === 0 ? <p className="log-empty">No delayed shipments.</p> : (
              <table>
                <thead><tr><th>Tracking ID</th><th>Location</th></tr></thead>
                <tbody>
                  {delayed.map((s) => (
                    <tr key={s.id}><td className="mono">{s.tracking_id}</td><td>{s.location}</td></tr>
                  ))}
                </tbody>
              </table>
            )}
          </Panel>
        </div>

        <Panel title="Recorded Risks">
          <table>
            <thead><tr><th>Risk Type</th><th>Severity</th><th>Solution</th></tr></thead>
            <tbody>
              {data.risk.risks.map((r) => (
                <tr key={r.id}><td>{r.risk_type}</td><td>{r.severity}</td><td>{r.solution}</td></tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
