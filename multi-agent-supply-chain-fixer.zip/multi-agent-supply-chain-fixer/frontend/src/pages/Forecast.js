// pages/Forecast.js
// -----------------------------------------------------------
// Displays the Demand Forecast Agent's predictions per product,
// with a bar chart comparing predicted demand vs current stock,
// and flags any demand spikes (>= 25%).
// -----------------------------------------------------------
import React, { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Tooltip, Legend } from "chart.js";
import { MdTrendingUp } from "react-icons/md";
import Topbar from "../components/Topbar";
import Panel from "../components/Panel";
import { getForecast, getInventory } from "../api/api";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

export default function Forecast() {
  const [forecast, setForecast] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getForecast(), getInventory()])
      .then(([fc, inv]) => {
        setForecast(fc.data);
        setInventory(inv.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const stockMap = Object.fromEntries(inventory.map((i) => [i.product_name, i.stock]));

  const chartData = {
    labels: forecast.map((f) => f.product),
    datasets: [
      { label: "Current Stock", data: forecast.map((f) => stockMap[f.product] || 0), backgroundColor: "#4C8DFF", borderRadius: 6 },
      { label: "Predicted Demand", data: forecast.map((f) => f.predicted_demand), backgroundColor: "#22D3B8", borderRadius: 6 },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: { legend: { labels: { color: "#8AA0BE" } } },
    scales: {
      x: { ticks: { color: "#8AA0BE", font: { size: 10 } }, grid: { display: false } },
      y: { ticks: { color: "#8AA0BE" }, grid: { color: "rgba(138,160,190,0.1)" } },
    },
  };

  return (
    <div>
      <Topbar title="Demand Forecast" subtitle="Predicted by the Demand Forecast Agent using sales history and stock trends." />
      <div className="page-content">
        <Panel title="Predicted Demand vs Current Stock" action={<MdTrendingUp size={20} color="var(--text-muted)" />}>
          {!loading && <Bar data={chartData} options={chartOptions} />}
        </Panel>

        <Panel title="Forecast Details" subtitle={loading ? "Loading…" : `${forecast.length} products forecasted`}>
          <table>
            <thead><tr><th>Product</th><th>Predicted Demand</th><th>Current Stock</th><th>Spike</th></tr></thead>
            <tbody>
              {forecast.map((f) => (
                <tr key={f.id}>
                  <td>{f.product}</td>
                  <td>{f.predicted_demand}</td>
                  <td>{stockMap[f.product] ?? "—"}</td>
                  <td>
                    <span className={`badge ${f.is_spike ? "badge-high" : "badge-low"}`}>
                      {f.spike_percent > 0 ? "+" : ""}{f.spike_percent}%
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>
      </div>
    </div>
  );
}
