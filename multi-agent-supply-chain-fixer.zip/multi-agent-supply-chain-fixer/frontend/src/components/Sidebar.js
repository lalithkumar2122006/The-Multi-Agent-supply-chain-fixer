// components/Sidebar.js
// -----------------------------------------------------------
// Left-hand navigation. Uses react-icons for a consistent icon
// set and react-router's NavLink-style active state (implemented
// manually with useLocation for a distinctive "route node" marker).
// -----------------------------------------------------------
import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  MdSpaceDashboard,
  MdInventory2,
  MdOutlinePeopleAlt,
  MdLocalShipping,
  MdOutlineShowChart,
  MdOutlineWarningAmber,
  MdOutlineHub,
  MdOutlineDescription,
  MdLogout,
} from "react-icons/md";
import { useAuth } from "../context/AuthContext";
import "./Sidebar.css";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: MdSpaceDashboard },
  { to: "/inventory", label: "Inventory", icon: MdInventory2 },
  { to: "/suppliers", label: "Suppliers", icon: MdOutlinePeopleAlt },
  { to: "/shipments", label: "Shipments", icon: MdLocalShipping },
  { to: "/forecast", label: "Forecast", icon: MdOutlineShowChart },
  { to: "/risk", label: "Risk Analysis", icon: MdOutlineWarningAmber },
  { to: "/agents", label: "Agent Activity", icon: MdOutlineHub },
  { to: "/reports", label: "Reports", icon: MdOutlineDescription },
];

export default function Sidebar() {
  const location = useLocation();
  const { user, logout } = useAuth();

  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <span className="brand-mark" />
        <div>
          <h1 className="brand-title">SupplyFix</h1>
          <p className="brand-subtitle">Multi-Agent Ops</p>
        </div>
      </div>

      <nav className="sidebar-nav">
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => {
          const active = location.pathname === to;
          return (
            <Link key={to} to={to} className={`nav-item ${active ? "active" : ""}`}>
              <span className="nav-node" />
              <Icon className="nav-icon" size={19} />
              <span>{label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="footer-user">
          <div className="user-avatar">{(user || "A").charAt(0).toUpperCase()}</div>
          <div>
            <p className="user-name">{user || "Guest"}</p>
            <p className="user-role">Operations Lead</p>
          </div>
        </div>
        {user && (
          <button className="logout-btn" onClick={logout} title="Log out">
            <MdLogout size={18} />
          </button>
        )}
      </div>
    </aside>
  );
}
