// components/Panel.js
// -----------------------------------------------------------
// Generic bordered "panel" container used to wrap charts, tables
// and lists consistently across every page.
// -----------------------------------------------------------
import React from "react";
import "./Panel.css";

export default function Panel({ title, subtitle, action, children, className = "" }) {
  return (
    <div className={`panel ${className}`}>
      {(title || action) && (
        <div className="panel-header">
          <div>
            {title && <h3 className="panel-title">{title}</h3>}
            {subtitle && <p className="panel-subtitle">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      <div className="panel-content">{children}</div>
    </div>
  );
}
