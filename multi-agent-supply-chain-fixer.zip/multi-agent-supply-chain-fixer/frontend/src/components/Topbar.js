// components/Topbar.js
// -----------------------------------------------------------
// Sticky top bar shown on every page: page title/subtitle on the
// left, dark/light mode toggle on the right.
// -----------------------------------------------------------
import React from "react";
import { MdOutlineDarkMode, MdOutlineLightMode } from "react-icons/md";
import { useTheme } from "../context/ThemeContext";
import "./Topbar.css";

export default function Topbar({ title, subtitle }) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="topbar">
      <div>
        <h2 className="topbar-title">{title}</h2>
        {subtitle && <p className="topbar-subtitle">{subtitle}</p>}
      </div>
      <button className="theme-toggle" onClick={toggleTheme} title="Toggle dark / light mode">
        {theme === "dark" ? <MdOutlineLightMode size={18} /> : <MdOutlineDarkMode size={18} />}
        <span>{theme === "dark" ? "Light" : "Dark"} mode</span>
      </button>
    </header>
  );
}
