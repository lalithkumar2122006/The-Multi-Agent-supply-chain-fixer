// components/StatCard.js
// -----------------------------------------------------------
// Small reusable KPI card used across the Dashboard.
// `tone` picks an accent color: "accent" | "amber" | "red" | "blue"
// -----------------------------------------------------------
import React from "react";
import "./StatCard.css";

export default function StatCard({ icon: Icon, label, value, tone = "accent", hint }) {
  return (
    <div className={`stat-card tone-${tone}`}>
      <div className="stat-icon">
        <Icon size={20} />
      </div>
      <div className="stat-body">
        <p className="stat-label">{label}</p>
        <h3 className="stat-value">{value}</h3>
        {hint && <p className="stat-hint">{hint}</p>}
      </div>
    </div>
  );
}
