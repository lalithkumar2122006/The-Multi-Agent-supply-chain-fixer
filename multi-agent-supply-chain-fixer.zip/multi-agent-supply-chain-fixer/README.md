# Multi-Agent Supply Chain Fixer

An AI-powered Supply Chain Management system where **6 collaborating AI agents**
detect supply chain problems (low stock, supplier under-performance, shipment
delays, demand spikes, and composite risk) and automatically suggest — or take —
corrective action.

Ask something like *"I have only 20 laptops left."* on the **Agent Activity**
page and watch the Coordinator Agent hand the query off to five specialist
agents in sequence, then combine their findings into one final recommendation.

---

## 1. Tech Stack

| Layer      | Technology |
|------------|------------|
| Frontend   | React.js, HTML, CSS, JavaScript, React Router, Axios, Chart.js, React Icons |
| Backend    | Python, FastAPI, Uvicorn |
| AI Layer   | Rule-based multi-agent engine (always on) + optional CrewAI / LangChain / OpenAI / Groq enrichment |
| Database   | SQLite (auto-created, auto-seeded) |

> **No API key required.** Every agent's core logic (detecting low stock,
> ranking suppliers, flagging delays, forecasting spikes, scoring risk) is
> deterministic Python, so the whole system works immediately after
> `pip install` — no OpenAI/Groq account needed. If you *do* set an
> `OPENAI_API_KEY` or `GROQ_API_KEY` environment variable and install the
> optional LangChain/CrewAI packages, each agent will additionally use a real
> LLM to rewrite its finding in more natural language (see
> `agents/llm_helper.py`).

---

## 2. Project Structure

```
multi-agent-supply-chain-fixer/
│
├── backend/
│   └── main.py                # FastAPI app entry point (run this with uvicorn)
│
├── agents/                    # The 6 AI agents
│   ├── inventory_agent.py
│   ├── supplier_agent.py
│   ├── logistics_agent.py
│   ├── forecast_agent.py
│   ├── risk_agent.py
│   ├── coordinator_agent.py
│   └── llm_helper.py          # Optional OpenAI/Groq/LangChain enrichment
│
├── api/                       # FastAPI route definitions
│   ├── routes_inventory.py
│   ├── routes_suppliers.py
│   ├── routes_shipments.py
│   ├── routes_forecast.py
│   ├── routes_risk.py
│   ├── routes_agent.py        # /ask-agent, /agent-logs
│   ├── routes_auth.py         # /login
│   └── schemas.py
│
├── database/
│   ├── db.py                  # SQLite connection + table creation
│   ├── seed.py                # Automatic sample-data seeding
│   └── supply_chain.db        # Created automatically on first run
│
├── frontend/                  # React application
│   ├── public/index.html
│   └── src/
│       ├── pages/             # Dashboard, Inventory, Suppliers, Shipments,
│       │                        Forecast, RiskAnalysis, AgentActivity, Reports, Login
│       ├── components/        # Sidebar, Topbar, Panel, StatCard
│       ├── context/           # ThemeContext (dark mode), AuthContext (login)
│       ├── api/api.js         # Axios client for every backend endpoint
│       └── styles/theme.css   # Design tokens (CSS variables) for dark/light mode
│
├── requirements.txt
└── README.md
```

---

## 3. The 6 AI Agents

| Agent | Responsibilities |
|-------|-------------------|
| **Inventory Agent** | Monitors stock levels, detects low inventory, recommends reorder quantity, updates the inventory database |
| **Supplier Agent** | Evaluates supplier performance, compares delivery times, suggests the best supplier, handles delays |
| **Logistics Agent** | Tracks shipments, detects delays, recommends express/faster routes, updates shipment status |
| **Demand Forecast Agent** | Predicts future demand, analyzes stock/sales trends, detects demand spikes |
| **Risk Analysis Agent** | Detects shortages/supplier-failure risk, generates a 0–100 composite risk score |
| **Coordinator Agent** | Receives the user's query, orchestrates all 5 agents, combines their output into one final recommendation |

### Pipeline

```
Coordinator Agent
   ↓
Inventory Agent
   ↓
Supplier Agent
   ↓
Logistics Agent
   ↓
Demand Forecast Agent
   ↓
Risk Analysis Agent
   ↓
Coordinator combines all outputs
   ↓
Final recommendation returned to the user
```

### Example

**Query:** *"I have only 20 laptops left."*

```
Inventory Agent  → Stock is below minimum (20 vs minimum 50).
Supplier Agent   → Order from Supplier A - TechSource Global.
Logistics Agent  → Express delivery recommended.
Forecast Agent   → Demand expected to increase ~40-60%.
Risk Agent       → Medium/High shortage risk.
Coordinator      → "Recommended order quantity: ~100+ laptops immediately.
                     Place the order with Supplier A. Use express delivery."
```

---

## 4. Database Tables

| Table | Columns |
|-------|---------|
| `inventory` | id, product_name, stock, minimum_stock, location |
| `suppliers` | id, supplier_name, rating, delivery_time |
| `orders` | id, product, quantity, status |
| `shipments` | id, tracking_id, location, status |
| `forecast` | id, product, predicted_demand |
| `risks` | id, risk_type, severity, solution |
| `users` | id, username, password *(demo login)* |
| `agent_logs` | id, agent_name, message, timestamp *(agent activity feed)* |

All tables are created automatically on first run, and sample data is
inserted automatically if the tables are empty — **no manual setup needed**.

---

## 5. Backend API Reference

| Method | Endpoint | Description |
|--------|----------|--------------|
| GET | `/inventory/` | List all inventory items (with low-stock flags) |
| POST | `/inventory/` | Add a new inventory item |
| PUT | `/inventory/{id}` | Update stock for an item |
| DELETE | `/inventory/{id}` | Delete an inventory item |
| GET | `/suppliers/` | List suppliers, ranked by performance score |
| POST | `/suppliers/` | Add a new supplier |
| DELETE | `/suppliers/{id}` | Delete a supplier |
| GET | `/shipments/` | List all shipments |
| PUT | `/shipments/{id}` | Update shipment status |
| GET | `/forecast/` | List demand forecasts, with spike detection |
| GET | `/risk/` | List recorded risks + live composite risk score |
| POST | `/ask-agent` | Run the full multi-agent pipeline for a query |
| GET | `/agent-logs` | Real-time agent activity log |
| POST | `/login` | Demo login (`admin` / `admin123`) |

Interactive Swagger docs are available automatically at **http://127.0.0.1:8000/docs**
once the backend is running.

---

## 6. Installation & Running

### Prerequisites
- Python 3.10+
- Node.js 18+ and npm

### Backend

```bash
# From the project root
pip install -r requirements.txt

cd backend
uvicorn main:app --reload
```

The API will be available at **http://127.0.0.1:8000** (docs at `/docs`).
The SQLite database and sample data are created automatically on first startup.

> **Optional — enable real LLM reasoning:**
> ```bash
> export OPENAI_API_KEY="sk-..."     # or export GROQ_API_KEY="gsk-..."
> ```
> Set this before starting uvicorn to have each agent's message rewritten by
> a real LLM via LangChain. Everything works without this step.

### Frontend

Open a second terminal:

```bash
cd frontend
npm install
npm start
```

The app will open at **http://127.0.0.1:3000**.

### Login

Use the demo credentials on the login screen:

```
Username: admin
Password: admin123
```

---

## 7. Frontend Pages

- **Dashboard** — Total Inventory, Low Stock, Pending Orders, Delayed Shipments, Risk Level + charts
- **Inventory** — Full CRUD, low-stock badges
- **Suppliers** — Live-ranked supplier scoring, add/delete
- **Shipments** — Tracking table with inline status updates
- **Forecast** — Predicted demand vs stock chart + spike detection
- **Risk Analysis** — Composite risk gauge, risk heatmap, recorded risks & solutions
- **Agent Activity** — Ask the agent crew a question, watch the animated pipeline run end-to-end, and view a real-time agent log feed
- **Reports** — Consolidated, printable executive summary across all domains

Includes: dark mode toggle, responsive layout, and a simple login gate.

---

## 8. Notes on the AI Framework Layer

The brief calls for CrewAI / LangChain / OpenAI / Groq. To keep the project
**100% runnable without any paid API keys**, the actual decision logic for
every agent is implemented as clear, deterministic Python (see the `agents/`
folder) — this is what actually powers every page and the `/ask-agent`
endpoint by default.

`agents/coordinator_agent.py` additionally includes a `build_crewai_crew()`
function showing exactly how the same 6 roles/responsibilities can be wired
into a real CrewAI `Crew` object if you install `crewai` and configure an
LLM provider — the JSON contract returned to the frontend stays identical
either way.

---

## 9. Tech Recap

```
Backend:  uvicorn main:app --reload   (run inside /backend)
Frontend: npm install && npm start    (run inside /frontend)
```

No placeholders. No pseudo-code. Every endpoint, page, and agent above is
fully implemented and was tested end-to-end before delivery.
